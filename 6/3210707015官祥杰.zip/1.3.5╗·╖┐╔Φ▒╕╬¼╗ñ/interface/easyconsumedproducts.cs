﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _1._3._5机房设备维护
{/// <summary>
/// 易耗品
/// </summary>
    internal interface easyconsumedproducts
{/// <summary>
/// 补充
/// </summary>
        void add();
}
}
