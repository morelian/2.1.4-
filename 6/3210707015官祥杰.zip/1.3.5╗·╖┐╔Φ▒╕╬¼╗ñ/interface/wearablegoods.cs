﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _1._3._5机房设备维护
{ 
/// <summary>
/// 易损品
/// </summary>
    internal interface wearablegoods
{
    /// <summary>
    /// 报修
    /// </summary>
  void repair();

}
}
