﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _1._3._6学生工作
{/// <summary>
/// 学生干部
/// </summary>
    internal interface studentcadre
    {/// <summary>
    /// 任命
    /// </summary>
        void appoint();
    }
}
