﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace _1._4._1教师登分
{/// <summary>
/// 教师
/// </summary>
    internal class Teacher
    {/// <summary>
    /// 工号
    /// </summary>
        public string Num { set; get; }
        /// <summary>
        /// 姓名
        /// </summary>

        public string Name { set; get; }
        /// <summary>
        /// 教学任务
        /// </summary>
        public Teachingtask[] Task { set; get; }
        /// <summary>
        /// 教师构造函数
        /// </summary>
        public Teacher(string num,string name)
        {
            this.Name = name;
            this.Num = num;
        }
        /// <summary>
        /// 添加教学任务
        /// </summary>
        public void Addtask()
        {
            WriteLine("请输入要输入的任务数:");
            int n = int.Parse(ReadLine());

            if (this.Task!=null)
            {
                int m = (n + this.Task.Length);
                Teachingtask[] task = new Teachingtask[m];
                int i ;
                for (i = 0; i < m; i++)
                {
                     task[i] = new Teachingtask();
                }
                    for (i = 0; i < this.Task.Length; i++)
                {
                    task[i].Mark = this.Task[i].Mark;
                    task[i].Term = this.Task[i].Term;
                    task[i].Course.Name = this.Task[i].Course.Name;
                    task[i].Course.Num= this.Task[i].Course.Num;
                    task[i].Course.Mark = this.Task[i].Course.Mark;
                }
                this.Task = task;
                for (i=this.Task.Length-n; i < this.Task.Length; i++)
                {
                    WriteLine($"请输入任务{i}的学期：");
                    this.Task[i].Term = ReadLine();
                    WriteLine($"请输入任务{i}的课程名称：");
                    this.Task[i].Course.Name = ReadLine();
                    WriteLine($"请输入任务{i}的课程{this.Task[i].Course.Name}的课程号：");
                    this.Task[i].Course.Num = ReadLine();
                    WriteLine($"请输入任务{i}的课程{this.Task[i].Course.Name}的学分：");
                    this.Task[i].Course.Mark = float.Parse(ReadLine());
                }
            }
            else
            {
                int i;
                Teachingtask[] task = new Teachingtask[n];
                for (i = 0; i < n; i++)
                {
                    task[i] = new Teachingtask();
                }
                this.Task = task;
                for ( i = 0; i < task.Length; i++)
                {
                    WriteLine($"请输入任务{i}的学期：");
                    this.Task[i].Term = ReadLine();
                    WriteLine($"请输入任务{i}的课程名称：");
                    this.Task[i].Course.Name = ReadLine();
                    WriteLine($"请输入任务{i}的课程{this.Task[i].Course.Name}的课程号：");
                    this.Task[i].Course.Num = ReadLine();
                    WriteLine($"请输入任务{i}的课程{this.Task[i].Course.Name}的学分：");
                    this.Task[i].Course.Mark = float.Parse(ReadLine());


                }
            }
        }
        /// <summary>
        /// 输出教学任务
        /// </summary>
       public void Puttask()
        {
            for (int i = 0; i < this.Task.Length&&this.Task[i]!=null; i++)
                WriteLine($"教学任务{i}:课程{this.Task[i].Course.Name}学期{this.Task[i].Term}");
        }
        /// <summary>
        /// 添加学生成绩
        /// </summary>
        public void Addscore()
        {
            Puttask();
            WriteLine("请选择第几个任务,按1选1：");
            int n = int.Parse(ReadLine());
            WriteLine("任务的学习的学生的数量");
            int c = int.Parse(ReadLine());
            this.Task[n].Mark = new Studentmark[c];
            for (int o = 0; o < c; o++)
            {
                this.Task[n].Mark[o] = new Studentmark();
            }
            for (int i=n;i==n;i++)
            for (int j = 0; j < this.Task[i].Mark.Length; j++)
            {
                WriteLine($"请输入任务{i}的课程{this.Task[i].Course.Name}的第一个学生的成绩：");
                WriteLine($"输入学生学号:");
                this.Task[i].Mark[j].Student.Num = ReadLine();
                WriteLine($"输入学生姓名:");
                this.Task[i].Mark[j].Student.Name = ReadLine();
                WriteLine($"输入学生班级:");
                this.Task[i].Mark[j].Student.Class = ReadLine();
                WriteLine($"输入学生考试状态:");
                this.Task[i].Mark[j].Behavior = ReadLine();
                WriteLine($"输入学生总评成绩:");
                this.Task[i].Mark[j].Score = float.Parse(ReadLine());
                WriteLine($"输入学生平时成绩:");
                this.Task[i].Mark[j].Dailygard = float.Parse(ReadLine());
                WriteLine($"输入学生期末成绩:");
                this.Task[i].Mark[j].Finalgard = float.Parse(ReadLine());
            }
        }
        /// <summary>
        /// 输出学生成绩
        /// </summary>
        public void Putscore()
        {
            Puttask();
            WriteLine("请选择第几个任务的学生成绩按1选1：");
            int a = int.Parse(ReadLine());
            for(int i =0; i < this.Task[a].Mark.Length; i++)
            {
                WriteLine($"学生学号:{this.Task[a].Mark[i].Student.Num} \n" +
                    $"学生姓名:{this.Task[a].Mark[i].Student.Name} \n" +
                    $"学生班级:{this.Task[a].Mark[i].Student.Class}\n" +
                    $" 学生考试状态:{this.Task[a].Mark[i].Behavior}\n" +
                    $"学生总评成绩:{this.Task[a].Mark[i].Score}\n 学生平时成绩:{this.Task[a].Mark[i].Dailygard} \n" +
                    $" 学生期末成绩:{this.Task[a].Mark[i].Finalgard}");
            }
        }
        /// <summary>
        /// 添加一个任务
        /// </summary>
        public void Addone()
        {
            int n = 1;

            if (this.Task != null)
            {
                int m = (n + this.Task.Length);
                Teachingtask[] task = new Teachingtask[m];
                int i;
                for (i = 0; i < m; i++)
                {
                    task[i] = new Teachingtask();
                }
                for (i = 0; i < this.Task.Length; i++)
                {
                    task[i].Mark = this.Task[i].Mark;
                    task[i].Term = this.Task[i].Term;
                    task[i].Course.Name = this.Task[i].Course.Name;
                    task[i].Course.Num = this.Task[i].Course.Num;
                    task[i].Course.Mark = this.Task[i].Course.Mark;
                }
                this.Task = task;
                for (i = this.Task.Length - n; i < this.Task.Length; i++)
                {
                    WriteLine($"请输入任务{i}的学期：");
                    this.Task[i].Term = ReadLine();
                    WriteLine($"请输入任务{i}的课程名称：");
                    this.Task[i].Course.Name = ReadLine();
                    WriteLine($"请输入任务{i}的课程{this.Task[i].Course.Name}的课程号：");
                    this.Task[i].Course.Num = ReadLine();
                    WriteLine($"请输入任务{i}的课程{this.Task[i].Course.Name}的学分：");
                    this.Task[i].Course.Mark = float.Parse(ReadLine());
                }
            }
            else
            {
                int i;
                Teachingtask[] task = new Teachingtask[n];
                for (i = 0; i < n; i++)
                {
                    task[i] = new Teachingtask();
                }
                this.Task = task;
                for (i = 0; i < task.Length; i++)
                {
                    WriteLine($"请输入任务{i}的学期：");
                    this.Task[i].Term = ReadLine();
                    WriteLine($"请输入任务{i}的课程名称：");
                    this.Task[i].Course.Name = ReadLine();
                    WriteLine($"请输入任务{i}的课程{this.Task[i].Course.Name}的课程号：");
                    this.Task[i].Course.Num = ReadLine();
                    WriteLine($"请输入任务{i}的课程{this.Task[i].Course.Name}的学分：");
                    this.Task[i].Course.Mark = float.Parse(ReadLine());


                }
            }
        }
        /// <summary>
        /// 批量添加学生成绩
        /// </summary>
        public void Addmorescor()
        { 
            for (int j = 0; j < this.Task.Length; j++)
            {
                WriteLine($"输入第{j+1}个任务的学生数量:");
                int n = int.Parse(ReadLine());
                this.Task[j].Mark = new Studentmark[n];
                for(int o = 0; o < n; o++)
                {
                    this.Task[j].Mark[o] = new Studentmark();
                }
            }
            for(int a=0;a<this.Task.Length;a++)
            for (int i = 0; i < this.Task[a].Mark.Length; i++)
            {
                    WriteLine($"输入第{a+1}个任务的第{i+1}任务的学生信息");
                    WriteLine($"学号: ");
                    this.Task[a].Mark[i].Student.Num = ReadLine();

                    WriteLine("姓名");
                   this.Task[a].Mark[i].Student.Name = ReadLine();
                    WriteLine("班级");
                  this.Task[a].Mark[i].Student.Class = ReadLine();
                    WriteLine("考试状态");
                       this.Task[a].Mark[i].Behavior = ReadLine();
                    WriteLine("总评成绩");
                        this.Task[a].Mark[i].Score = float.Parse(ReadLine());
                    WriteLine("平时成绩");
                        this.Task[a].Mark[i].Dailygard = float.Parse(ReadLine());
                    WriteLine("期末成绩");
                this.Task[a].Mark[i].Finalgard = float.Parse(ReadLine());
        }
        }
    }
}
