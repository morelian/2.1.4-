﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _1._3._7毕业论文指导
{/// <summary>
/// 毕业论文导师
/// </summary>
    internal interface undergraduatethesistutor
    {/// <summary>
    /// 指导
    /// </summary>
        void guide();
        /// <summary>
        /// 答辩
        /// </summary>
        void reply();
    }
}
