﻿namespace _2._1._4学生管理
{
    partial class Studentinformation
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.add_ = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.textstudentname = new System.Windows.Forms.TextBox();
            this.textstudentnum = new System.Windows.Forms.TextBox();
            this.textstudentbirthday = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.Nan_ = new System.Windows.Forms.RadioButton();
            this.Nv_ = new System.Windows.Forms.RadioButton();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.radioButton5 = new System.Windows.Forms.RadioButton();
            this.radioButton6 = new System.Windows.Forms.RadioButton();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.Dan_ = new System.Windows.Forms.RadioButton();
            this.Tuan_ = new System.Windows.Forms.RadioButton();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.CIty_ = new System.Windows.Forms.RadioButton();
            this.Country_ = new System.Windows.Forms.RadioButton();
            this.Qun_ = new System.Windows.Forms.RadioButton();
            this.Wu_ = new System.Windows.Forms.RadioButton();
            this.curr_ = new System.Windows.Forms.CheckBox();
            this.Pe_ = new System.Windows.Forms.CheckBox();
            this.Obey_ = new System.Windows.Forms.CheckBox();
            this.button1 = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.SuspendLayout();
            // 
            // add_
            // 
            this.add_.Font = new System.Drawing.Font("宋体", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.add_.Location = new System.Drawing.Point(426, 312);
            this.add_.Name = "add_";
            this.add_.Size = new System.Drawing.Size(87, 32);
            this.add_.TabIndex = 0;
            this.add_.Text = "保存";
            this.add_.UseVisualStyleBackColor = true;
            this.add_.Click += new System.EventHandler(this.add__Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("宋体", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label1.Location = new System.Drawing.Point(166, 156);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(69, 19);
            this.label1.TabIndex = 1;
            this.label1.Text = "姓名：";
            // 
            // textstudentname
            // 
            this.textstudentname.Location = new System.Drawing.Point(295, 157);
            this.textstudentname.Name = "textstudentname";
            this.textstudentname.Size = new System.Drawing.Size(135, 21);
            this.textstudentname.TabIndex = 2;
            // 
            // textstudentnum
            // 
            this.textstudentnum.Location = new System.Drawing.Point(295, 84);
            this.textstudentnum.Name = "textstudentnum";
            this.textstudentnum.Size = new System.Drawing.Size(135, 21);
            this.textstudentnum.TabIndex = 3;
            // 
            // textstudentbirthday
            // 
            this.textstudentbirthday.Location = new System.Drawing.Point(295, 229);
            this.textstudentbirthday.Name = "textstudentbirthday";
            this.textstudentbirthday.Size = new System.Drawing.Size(135, 21);
            this.textstudentbirthday.TabIndex = 4;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("宋体", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label2.Location = new System.Drawing.Point(166, 86);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(69, 19);
            this.label2.TabIndex = 5;
            this.label2.Text = "学号：";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("宋体", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label3.Location = new System.Drawing.Point(166, 231);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(69, 19);
            this.label3.TabIndex = 6;
            this.label3.Text = "生日：";
            // 
            // Nan_
            // 
            this.Nan_.AutoSize = true;
            this.Nan_.ForeColor = System.Drawing.SystemColors.ControlText;
            this.Nan_.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.Nan_.Location = new System.Drawing.Point(6, 20);
            this.Nan_.Name = "Nan_";
            this.Nan_.Size = new System.Drawing.Size(35, 16);
            this.Nan_.TabIndex = 7;
            this.Nan_.TabStop = true;
            this.Nan_.Text = "男";
            this.Nan_.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.Nan_.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.Nan_.UseVisualStyleBackColor = true;
            this.Nan_.CheckedChanged += new System.EventHandler(this.Nan__CheckedChanged);
            // 
            // Nv_
            // 
            this.Nv_.AutoSize = true;
            this.Nv_.Location = new System.Drawing.Point(6, 42);
            this.Nv_.Name = "Nv_";
            this.Nv_.Size = new System.Drawing.Size(35, 16);
            this.Nv_.TabIndex = 8;
            this.Nv_.TabStop = true;
            this.Nv_.Text = "女";
            this.Nv_.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.Nan_);
            this.groupBox1.Controls.Add(this.groupBox3);
            this.groupBox1.Controls.Add(this.Nv_);
            this.groupBox1.Location = new System.Drawing.Point(644, 66);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(52, 65);
            this.groupBox1.TabIndex = 9;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "性别";
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.radioButton5);
            this.groupBox3.Controls.Add(this.radioButton6);
            this.groupBox3.Location = new System.Drawing.Point(47, 0);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(52, 65);
            this.groupBox3.TabIndex = 11;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "来源";
            // 
            // radioButton5
            // 
            this.radioButton5.AutoSize = true;
            this.radioButton5.ForeColor = System.Drawing.SystemColors.ControlText;
            this.radioButton5.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.radioButton5.Location = new System.Drawing.Point(6, 20);
            this.radioButton5.Name = "radioButton5";
            this.radioButton5.Size = new System.Drawing.Size(47, 16);
            this.radioButton5.TabIndex = 7;
            this.radioButton5.TabStop = true;
            this.radioButton5.Text = "城市";
            this.radioButton5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.radioButton5.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.radioButton5.UseVisualStyleBackColor = true;
            // 
            // radioButton6
            // 
            this.radioButton6.AutoSize = true;
            this.radioButton6.Location = new System.Drawing.Point(6, 42);
            this.radioButton6.Name = "radioButton6";
            this.radioButton6.Size = new System.Drawing.Size(47, 16);
            this.radioButton6.TabIndex = 8;
            this.radioButton6.TabStop = true;
            this.radioButton6.Text = "农村";
            this.radioButton6.UseVisualStyleBackColor = true;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.Wu_);
            this.groupBox4.Controls.Add(this.Qun_);
            this.groupBox4.Controls.Add(this.Dan_);
            this.groupBox4.Controls.Add(this.Tuan_);
            this.groupBox4.Location = new System.Drawing.Point(644, 200);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(96, 126);
            this.groupBox4.TabIndex = 12;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "政治面貌";
            this.groupBox4.Enter += new System.EventHandler(this.groupBox4_Enter);
            // 
            // Dan_
            // 
            this.Dan_.AutoSize = true;
            this.Dan_.ForeColor = System.Drawing.SystemColors.ControlText;
            this.Dan_.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.Dan_.Location = new System.Drawing.Point(6, 20);
            this.Dan_.Name = "Dan_";
            this.Dan_.Size = new System.Drawing.Size(47, 16);
            this.Dan_.TabIndex = 7;
            this.Dan_.TabStop = true;
            this.Dan_.Text = "党员";
            this.Dan_.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.Dan_.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.Dan_.UseVisualStyleBackColor = true;
            // 
            // Tuan_
            // 
            this.Tuan_.AutoSize = true;
            this.Tuan_.Location = new System.Drawing.Point(6, 42);
            this.Tuan_.Name = "Tuan_";
            this.Tuan_.Size = new System.Drawing.Size(47, 16);
            this.Tuan_.TabIndex = 8;
            this.Tuan_.TabStop = true;
            this.Tuan_.Text = "团员";
            this.Tuan_.UseVisualStyleBackColor = true;
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.CIty_);
            this.groupBox5.Controls.Add(this.Country_);
            this.groupBox5.Location = new System.Drawing.Point(697, 66);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(52, 65);
            this.groupBox5.TabIndex = 13;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "来源";
            // 
            // CIty_
            // 
            this.CIty_.AutoSize = true;
            this.CIty_.ForeColor = System.Drawing.SystemColors.ControlText;
            this.CIty_.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.CIty_.Location = new System.Drawing.Point(6, 20);
            this.CIty_.Name = "CIty_";
            this.CIty_.Size = new System.Drawing.Size(47, 16);
            this.CIty_.TabIndex = 7;
            this.CIty_.TabStop = true;
            this.CIty_.Text = "城市";
            this.CIty_.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.CIty_.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.CIty_.UseVisualStyleBackColor = true;
            // 
            // Country_
            // 
            this.Country_.AutoSize = true;
            this.Country_.Location = new System.Drawing.Point(6, 42);
            this.Country_.Name = "Country_";
            this.Country_.Size = new System.Drawing.Size(47, 16);
            this.Country_.TabIndex = 8;
            this.Country_.TabStop = true;
            this.Country_.Text = "农村";
            this.Country_.UseVisualStyleBackColor = true;
            // 
            // Qun_
            // 
            this.Qun_.AutoSize = true;
            this.Qun_.Location = new System.Drawing.Point(6, 64);
            this.Qun_.Name = "Qun_";
            this.Qun_.Size = new System.Drawing.Size(47, 16);
            this.Qun_.TabIndex = 9;
            this.Qun_.TabStop = true;
            this.Qun_.Text = "群众";
            this.Qun_.UseVisualStyleBackColor = true;
            // 
            // Wu_
            // 
            this.Wu_.AutoSize = true;
            this.Wu_.Location = new System.Drawing.Point(6, 86);
            this.Wu_.Name = "Wu_";
            this.Wu_.Size = new System.Drawing.Size(83, 16);
            this.Wu_.TabIndex = 10;
            this.Wu_.TabStop = true;
            this.Wu_.Text = "无党派人士";
            this.Wu_.UseVisualStyleBackColor = true;
            // 
            // curr_
            // 
            this.curr_.AutoSize = true;
            this.curr_.Location = new System.Drawing.Point(644, 137);
            this.curr_.Name = "curr_";
            this.curr_.Size = new System.Drawing.Size(96, 16);
            this.curr_.TabIndex = 14;
            this.curr_.Text = "是否为应届生";
            this.curr_.UseVisualStyleBackColor = true;
            // 
            // Pe_
            // 
            this.Pe_.AutoSize = true;
            this.Pe_.Location = new System.Drawing.Point(644, 156);
            this.Pe_.Name = "Pe_";
            this.Pe_.Size = new System.Drawing.Size(96, 16);
            this.Pe_.TabIndex = 15;
            this.Pe_.Text = "是否体检受限";
            this.Pe_.UseVisualStyleBackColor = true;
            // 
            // Obey_
            // 
            this.Obey_.AutoSize = true;
            this.Obey_.Location = new System.Drawing.Point(644, 178);
            this.Obey_.Name = "Obey_";
            this.Obey_.Size = new System.Drawing.Size(96, 16);
            this.Obey_.TabIndex = 16;
            this.Obey_.Text = "是否服从调剂";
            this.Obey_.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("宋体", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button1.Location = new System.Drawing.Point(186, 312);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(69, 32);
            this.button1.TabIndex = 17;
            this.button1.Text = "查找";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Studentinformation
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::_2._1._4学生管理.Properties.Resources._20220531215242;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.Obey_);
            this.Controls.Add(this.Pe_);
            this.Controls.Add(this.curr_);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.textstudentbirthday);
            this.Controls.Add(this.textstudentnum);
            this.Controls.Add(this.textstudentname);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.add_);
            this.DoubleBuffered = true;
            this.Name = "Studentinformation";
            this.Text = "学生信息管理系统";
            this.Load += new System.EventHandler(this.Studentinformation_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button add_;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textstudentname;
        private System.Windows.Forms.TextBox textstudentnum;
        private System.Windows.Forms.TextBox textstudentbirthday;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.RadioButton Nan_;
        private System.Windows.Forms.RadioButton Nv_;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.RadioButton radioButton5;
        private System.Windows.Forms.RadioButton radioButton6;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.RadioButton Dan_;
        private System.Windows.Forms.RadioButton Tuan_;
        private System.Windows.Forms.RadioButton Wu_;
        private System.Windows.Forms.RadioButton Qun_;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.RadioButton CIty_;
        private System.Windows.Forms.RadioButton Country_;
        private System.Windows.Forms.CheckBox curr_;
        private System.Windows.Forms.CheckBox Pe_;
        private System.Windows.Forms.CheckBox Obey_;
        private System.Windows.Forms.Button button1;
    }
}

