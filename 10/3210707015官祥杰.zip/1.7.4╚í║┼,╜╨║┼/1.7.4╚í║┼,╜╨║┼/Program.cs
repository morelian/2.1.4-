﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _1._7._4取号_叫号
{
    internal class Program
    {
        static void Main(string[] args)
        {

            Reservationmanager Book = new Reservationmanager();
          
            Book.Takenumber();
            Book.Takenumber();
            Book.Takenumber();
            Book.Callnumber();
            Book.Takenumber();
            Book.Takenumber();
            Book.Takenumber();
            Book.Callnumber();
            Book.Callnumber();
        }
    }
}
