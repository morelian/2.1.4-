﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace _1._4._1教师登分
{
    internal class Program
    {
        static void Main()
        {
            Teacher teacher = new Teacher("001", "沐兰");
            Course[] course =
            {
                new Course("001","面向对象程序设计",float.Parse("5")),
                new Course("002","数据结构",float.Parse("5")),
                new Course("003","计算机网络",float.Parse("5"))
             };
            Teachingtask[] task =
            {
                new Teachingtask("2022-2023学年",course[0]),
                new Teachingtask("2022-2023学年",course[1]),
                new Teachingtask("2022-2023学年",course[2])
                
            };
            teacher.Task = task;
            while (true)
            {
                WriteLine($"按1添加教学任务，按2批量增加教学任务，按3添加学生成绩，按4批量增加学生成绩，按5显示教学任务，按6显示学生成绩:");
                int a = int.Parse(ReadLine());
                if(a==1)
                teacher.Addone();
                if (a == 2)
                    teacher.Addtask();
                if (a == 3)
                    teacher.Addscore();
                if (a == 4)
                    teacher.Addmorescor();
                if (a == 5)
                    teacher.Puttask();
                if (a == 6)
                    teacher.Putscore();

            }
        }
    }
}
