﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _1._4._1教师登分
{/// <summary>
/// 教学任务
/// </summary>
    internal class Teachingtask
    {/// <summary>
    /// 学期
    /// </summary>
        public string Term { set; get; }
        /// <summary>
        /// 课程
        /// </summary>
        public Course Course { set; get; }
        /// <summary>
        /// 学生成绩
        /// </summary>
        public Studentmark[] Mark { set; get; }
        public Teachingtask(string term,Course course)
        {
            this.Course = course;
            this.Term = term;
            this.Mark = null;
        }
        public Teachingtask()
        {
            this.Term = null;
            this.Course = new Course();
            this.Mark = null;
        }
    }
}
